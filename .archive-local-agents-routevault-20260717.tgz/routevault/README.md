# RouteVault

**Primary Location:** `/home/gumbyender/agents/routevault/`

This is the consolidated, local working home for the entire RouteVault project.

## Project Goal

RouteVault is a research & analysis tool for AI tinkerers focused on deep historical price analysis combined with benchmark/performance data. The aim is to help power users understand how model value (price vs capability) changes over time.

## Folder Structure

```
routevault/
├── README.md
├── code/
│   └── routevault-staging/          # Full original implementation
├── planning/                        # Original project planning docs (from Obsidian)
│   ├── Project-Plan.md
│   ├── Business-Model.md
│   ├── How-We-Weight-Models.md
│   ├── Competitors.md
│   ├── RouteVault-Kanban.md
│   └── designs/
├── knowledge/                       # Analysis & strategy documents
│   ├── TAKEOVER-PLAN.md             # ← Master document (start here)
│   ├── CURRENT-STATE.md
│   └── GAP-ANALYSIS.md
└── data/
    ├── models.json
    └── routevault.db
```

## Important Documents

**Start here:**
- `knowledge/TAKEOVER-PLAN.md`

**Planning:**
- `planning/Project-Plan.md`
- `planning/Business-Model.md`
- `planning/How-We-Weight-Models.md`
- `planning/RouteVault-Kanban.md`

## Notes

- All future work for RouteVault should live inside this folder.
- The original files on the NAS (`/mnt/nas/...`) remain as backup.
- This location (under `/home/gumbyender/agents/`) is now the official working directory for the project.

---

*Project consolidated here on 2026-05-15.*