---
kanban-plugin: board
tags: [routevault, saas, ai-models, planning, mockups]
status: active
---

## Backlog

- [ ] Add user-configurable weighting sliders / priority settings (Phase 2)
- [ ] Create production GitHub repo + deploy pipeline (routevault.ai)
- [ ] Implement smart router + recommendation engine (Phase 2.5)
- [ ] Wire real historical pricing data from SQLite into model detail pages
- [ ] Add price change indicators and “Price Intelligence” layer across the site

## To Do

- [ ] Copy `routevault.db` from `~/routevault-data/` into the staging repo
- [ ] Create utility scripts (`show_price_history.py`, `price_change_report.py`)
- [ ] Expose price history via simple query functions for the frontend

## In Progress

- [ ] Integrate historical pricing data into the UI (start with model-detail.html)

## Review

## Done

- [x] **Phase 1 Static Mockups Complete** — `routevault-staging` repo contains working HTML for:
  - Landing (`index.html`)
  - Models list + comparison (`models.html`)
  - Model detail (`model-detail.html`)
  - Pricing tiers (`pricing.html`)
  - Auth pages (`login.html`, `register.html`)
  - Admin dashboard (`admin-dashboard.html`)
  - How we score (`how-we-score.html`)
  - Ecosystem (`ecosystem.html`)
- [x] Dual-layer weighting system defined (Technical benchmarks + Consumer-friendly RouteVault Scale)
- [x] Technical metrics table populated with 18 models (LMSYS, GPQA, SWE-Bench, latency, tool use)
- [x] Precise consumer-category mapping rules + scoring thresholds defined
- [x] Interactive onboarding quiz with smart recommendations (`quiz.html`)
- [x] SQLite database created with models + 90-day price history (17 models, 1,530 records)
- [x] Kanban board updated to current state (May 2026)

%% kanban:settings
```
{"kanban-plugin":"board","list-collapse":[false,false,false,false,false]}
```
%%