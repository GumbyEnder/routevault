# RouteVault — Current State (May 2026)

**Last updated:** 2026-05-14 (after Quiz improvements)

## Code Repository
**Path:** `/mnt/nas/github_repos/routevault-staging`

### Pages Status

| Page | Visual Quality | Functional Quality | Notes |
|------|----------------|--------------------|-------|
| `index.html` | High | Medium | Good landing, mostly marketing |
| `quiz.html` | High | **Good (improved)** | Now loads real `models.json` + dual-layer scoring |
| `models.html` | High | Low-Medium | List exists, limited intelligence |
| `model-detail.html` | High | Good | Best data integration (price history via Chart.js) |
| `harness-detail-hermes.html` | Medium | Low | Concept page, mostly placeholder |
| `pricing.html` | High | Low | Marketing copy |
| `ecosystem.html` | High | Low | Marketing |
| `how-we-score.html` | High | Low | Good intentions, thin content |
| `admin-dashboard.html` | Medium | Low | Placeholder |

### Data Layer

- **SQLite DB** (`scripts/routevault.db`): 17 models + 1,530 price history records
- **Export** (`data/models.json`): Generated from DB, includes `rv_label`, pricing, context, price_history
- Python tooling exists and is decent (`export_model_data.py`, `price_change_report.py`, etc.)

### Recent Improvements (May 2026)

- Quiz is now data-driven
- Scoring logic improved and aligned with weighting strategy
- Recommendation cards show real input/output pricing per million

---

## Obsidian Planning

**Main folder:** `/mnt/nas/Obsidian Vault/RouteVault/`

Key documents:
- `Project Plan.md` — Phased approach, current status
- `Business Model.md` — Strong "BestRoute" value prop
- `How do we weight models.md` — Best technical document (dual-layer system)
- `Kanban/RouteVault.md` — Active task tracking

---

## Overall Maturity

- **Visual / Design:** 8/10 (very strong for a solo project)
- **Data Foundation:** 6/10 (real DB + export, but underutilized)
- **Intelligence / Features:** 3/10 (mostly mock until recent Quiz work)
- **Production Readiness:** 1/10 (still staging repo, no deployment)

**Bottom line:** Excellent starting point. The biggest risk is staying in "beautiful mockup" territory too long.