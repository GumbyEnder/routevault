# RouteVault Takeover Plan

**Project:** RouteVault (AI Model Intelligence + Smart Router)  
**Status:** Phase 1 complete (strong mockups) → Early Phase 2 (data integration started)  
**Last Updated:** 2026-05-14  
**Owner:** GumbyEnder + Grok Build instances

---

## Executive Summary

RouteVault is a consumer-friendly platform that helps users (and agents) choose the right AI model for their needs at the right price. It combines:

- Transparent model intelligence (technical + consumer-friendly scoring)
- Price history tracking and "Price Intelligence"
- Smart recommendations and (future) routing

The project currently has **excellent visual foundations** (Phase 1 mockups are high quality) but is **functionally behind** the documented vision. The Quiz and data layer are the most advanced parts after recent work.

**Goal of this plan:** Give any Grok Build instance (or the human) a clear, prioritized path to take over and advance the project from "beautiful mockup" to a genuinely useful product.

---

## Current State (May 2026)

### What Exists and is Strong

**Code (`/mnt/nas/github_repos/routevault-staging`):**
- High-quality, consistent dark SaaS design system
- Full set of static pages (index, quiz, models, model-detail, pricing, ecosystem, how-we-score, admin)
- Real SQLite database + price history (17 models, 1,530 records)
- `data/models.json` export with `rv_label`, pricing, context, price_history
- Working price history visualization in `model-detail.html` (Chart.js)
- **Quiz** — Now data-driven (as of May 2026 updates):
  - Loads real models from `models.json`
  - Uses improved dual-layer scoring (Technical + RouteVault Scale)
  - Shows real input/output pricing per million

**Obsidian Planning (`/mnt/nas/Obsidian Vault/RouteVault/`):**
- `Project Plan.md` — Clear phased approach
- `Business Model.md` — Strong value proposition (BestRoute concept)
- `How do we weight models.md` — Excellent dual-layer weighting strategy
- `Kanban/RouteVault.md` — Active board with clear backlog

### What is Weak / Missing

- Most intelligence is still mock or partially implemented
- Quiz was the only page doing real work until recent improvements
- No user-configurable weighting
- No Price Intelligence layer on the Models page
- No smart router
- No production deployment (`routevault.ai`)
- Hermes harness page is mostly placeholder
- Technical metrics (LMSYS, GPQA, SWE-Bench, etc.) are not exposed in the UI

---

## Vision vs Reality Gap

| Vision (Business Model + Weighting Doc) | Current Reality | Gap Size |
|-----------------------------------------|------------------|----------|
| Dual-layer scoring (Technical + Consumer) | Partially implemented in Quiz only | Large |
| Consumer-friendly RouteVault Scale labels | Data exists, UI barely uses it | Medium-Large |
| Price Intelligence + change indicators | Only visible in model-detail | Large |
| User-configurable weighting sliders | Not built | High |
| Smart router + recommendation engine | Quiz is first step, router doesn't exist | High |
| Harness intelligence (especially Hermes) | One thin page | High |
| Production site + real usage | Still in `routevault-staging` | High |

---

## Strategic Positioning

RouteVault should become **the consumer intelligence layer** on top of raw providers and harnesses (starting with Hermes).

**Unique value:**
- Price transparency + history (most competitors show current price only)
- Human-readable scoring ("Project Planner", "Budget Everyday") instead of just benchmark tables
- Tight integration with powerful local harnesses (Hermes as a first-class citizen)
- Future: Smart routing that actually saves users money

---

## Phased Roadmap

### Phase 2A – Make the Data Real (Next 2–4 weeks) — **Current Focus**

Goal: Turn the beautiful mockup into something that feels genuinely intelligent.

**Priorities:**
1. **Quiz** — Done (data-driven + improved scoring) — Maintain & refine
2. **Price Change Indicators + Price Intelligence** on `models.html` and model cards
3. Basic scoring engine exposed in the UI (not just in the quiz)
4. Improve `model-detail.html` further (better reasons, comparison tools)
5. Flesh out `harness-detail-hermes.html` with real data

### Phase 2B – User Control & Polish (Following 3–5 weeks)

- User-configurable weighting sliders (core feature from the weighting doc)
- Better recommendation engine that combines profile + user weights
- "My Stack" persistence (localStorage → later account)
- Stronger Models page with filters + signals

### Phase 2C – Router & Production

- Smart router logic (even if simple at first)
- Create production repository + deployment pipeline (`routevault.ai`)
- Basic auth + saved preferences
- Start actual routing (OpenRouter proxy or direct)

### Phase 3+ (Future)

- Team features
- Harness marketplace
- Deeper Hermes integration (Hermes using RouteVault for model selection)
- Real usage data and feedback loops

---

## Immediate Priorities (Next 4–6 Weeks)

| Rank | Task | Why | Effort | Status (May 14) |
|------|------|-----|--------|-----------------|
| 1 | Price change indicators + Price Intelligence layer on Models page | Directly addresses backlog + vision | Medium | Not started |
| 2 | Expose basic scoring / RV Score more widely in the UI | Makes the dual-layer system visible | Medium | Partial (only in quiz) |
| 3 | Significantly improve `harness-detail-hermes.html` | Strategic tie to main agent work | Medium | Very early |
| 4 | Refine Quiz scoring + reasons based on real usage feedback | Highest user-facing impact | Medium | In progress |
| 5 | Create production repo + basic deployment | Unblocks real usage and SEO | Medium | Not started |
| 6 | User-configurable weighting sliders | Core feature from planning docs | High | Not started |

---

## Technical Recommendations

- **Stay static-first** for as long as possible (SEO advantage).
- Keep using `data/models.json` as the frontend contract (easy to generate from SQLite).
- The Python scripts in `scripts/` are good — consider adding a weekly automated export job later.
- For the router (Phase 2C+), consider a lightweight proxy layer (Cloudflare Workers or Fly.io) that can do BYOK (Bring Your Own Key).

---

## Working with This Project (Grok Workflow)

**Recommended split:**

- **Planning, tasks, decisions** → Obsidian (`/mnt/nas/Obsidian Vault/RouteVault/`)
- **Code changes** → `/mnt/nas/github_repos/routevault-staging`
- **Shared memory across Grok instances** → `/mnt/nas/github_repos/grok-build-knowledge/routevault/`

Always read the latest `Project Plan.md` and `Kanban/RouteVault.md` via the Local REST API before starting work.

---

## Open Questions

- How important is real routing (vs just recommendations) in the next 3 months?
- Should Hermes become a first-class integration point early (even as a prototype)?
- Do we want to keep the project fully static for SEO, or introduce a lightweight backend sooner?
- What is the target launch timeline for a public `routevault.ai`?

---

**Next Action (as of May 14, 2026):**

Continue with **Priority #1** — Add price change indicators and a basic Price Intelligence layer to the Models page.

---

*This document is the single source of truth for taking over RouteVault. Update it as the project evolves.*